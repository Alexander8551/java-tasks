package bank;

import java.util.*;

public class Bank {
    private List<Person> persons = new ArrayList<>();
    private List<Account> accounts = new ArrayList<>();

    public Person createPerson(String name) {
        Person p = new Person(name);
        persons.add(p);
        Logger.getInstance().log("Создан клиент: " + name);
        return p;
    }

    public Account openAccount(Person person, AccountType type) {
        Account acc = new Account(person, type);
        accounts.add(acc);
        person.addAccount(acc);
        Logger.getInstance().log("Открыт счет " + acc.getId() + " для " + person.getName() + " (" + type + ")");
        return acc;
    }

    public void deposit(Account acc, double amount) {
        acc.deposit(amount);
        Logger.getInstance().log("Пополнение счета " + acc.getId() + " на " + amount);
    }

    public void withdraw(Account acc, double amount) {
        acc.withdraw(amount);
        Logger.getInstance().log("Снятие со счета " + acc.getId() + " суммы " + amount);
    }

    public void applyInterest(Account acc) {
        acc.applyInterest();
        Logger.getInstance().log("Начисление процентов на счет " + acc.getId());
    }
}