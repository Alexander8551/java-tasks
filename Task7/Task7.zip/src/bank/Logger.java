package bank;

import java.util.*;
import java.io.*;

public class Logger {
    private static Logger instance;
    private List<String> log = new ArrayList<>();
    private final String LOG_FILE = "log.txt";

    private Logger() {}

    public static Logger getInstance() {
        if (instance == null) instance = new Logger();
        return instance;
    }

    public void log(String message) {
        log.add(message);
        // Запись в файл с UTF-8
        try (OutputStreamWriter osw = new OutputStreamWriter(
                new FileOutputStream(LOG_FILE, true), "UTF-8");
             BufferedWriter bw = new BufferedWriter(osw)) {
            bw.write(message);
            bw.newLine();
        } catch (IOException e) {
            System.err.println("Ошибка записи в лог-файл: " + e.getMessage());
        }
    }

    public void printLog() {
        System.out.println("--- Журнал операций ---");
        for (String entry : log) {
            System.out.println(entry);
        }
    }

    public void clear() {
        log.clear();
        // Очистить файл (с UTF-8)
        try (OutputStreamWriter osw = new OutputStreamWriter(
                new FileOutputStream(LOG_FILE, false), "UTF-8")) {
            // Просто открываем файл с флагом false (перезапись) — файл очистится
        } catch (IOException e) {
            System.err.println("Ошибка очистки лог-файла: " + e.getMessage());
        }
    }

    public List<String> getLog() {
        return log;
    }
}
