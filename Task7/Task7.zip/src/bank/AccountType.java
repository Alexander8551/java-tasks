package bank;

public enum AccountType {
    SAVINGS(0.03, true), // С процентами
    CHECKING(0.0, false); // Без процентов

    private final double interestRate;
    private final boolean hasInterest;

    AccountType(double interestRate, boolean hasInterest) {
        this.interestRate = interestRate;
        this.hasInterest = hasInterest;
    }

    public double getInterestRate() {
        return interestRate;
    }

    public boolean hasInterest() {
        return hasInterest;
    }
}