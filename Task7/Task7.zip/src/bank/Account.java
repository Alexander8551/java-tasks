package bank;

public class Account {
    private static int counter = 1;
    private int id;
    private double balance;
    private Person owner;
    private AccountType type;

    public Account(Person owner, AccountType type) {
        this.id = counter++;
        this.owner = owner;
        this.type = type;
        this.balance = 0;
    }

    public int getId() {
        return id;
    }

    public double getBalance() {
        return balance;
    }

    public Person getOwner() {
        return owner;
    }

    public AccountType getType() {
        return type;
    }

    public void deposit(double amount) {
        if (amount <= 0) throw new IllegalArgumentException("Сумма должна быть положительной");
        balance += amount;
    }

    public void withdraw(double amount) {
        if (amount <= 0) throw new IllegalArgumentException("Сумма должна быть положительной");
        if (amount > balance) throw new IllegalArgumentException("Недостаточно средств");
        balance -= amount;
    }

    public void applyInterest() {
        if (type.hasInterest()) {
            double interest = balance * type.getInterestRate();
            balance += interest;
        }
    }
}