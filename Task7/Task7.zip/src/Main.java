import bank.*;

public class Main {
    public static void main(String[] args) {
        Bank bank = new Bank();

        // Создаем клиента с именем "Иван Иванов"
        Person p1 = bank.createPerson("Иван Иванов");

        // Открываем два счета для клиента: сберегательный и расчетный
        Account acc1 = bank.openAccount(p1, AccountType.SAVINGS);   // Счет с процентами
        Account acc2 = bank.openAccount(p1, AccountType.CHECKING);  // Счет без процентов

        // Вносим на первый счет 1000 рублей
        bank.deposit(acc1, 1000);

        // Снимаем с первого счета 200 рублей
        bank.withdraw(acc1, 200);

        // Вносим на второй счет 500 рублей
        bank.deposit(acc2, 500);

        // Выводим балансы обоих счетов
        System.out.println("Баланс счета 1: " + acc1.getBalance());
        System.out.println("Баланс счета 2: " + acc2.getBalance());

        // Начисляем проценты на первый счет (если они предусмотрены)
        bank.applyInterest(acc1);

        // Выводим баланс первого счета после начисления процентов
        System.out.println("Баланс счета 1 после начисления процентов: " + acc1.getBalance());

        // Показываем журнал всех операций
        Logger.getInstance().printLog();
    }
}
