package main.java;
public class Main {
    public static void main(String[] args) {
        try {
            // Создаем первого студента с корректными данными
            Student student1 = new Student("Иван Иванов", "+79991234567", 3);

            // Добавляем оценку по предмету
            student1.addGrade("Математика", 85);

            // Запрашиваем справку для пропуска пары три раза
            student1.requestAbsenceCertificate();
            student1.requestAbsenceCertificate();
            student1.requestAbsenceCertificate();

            // Попытка запросить еще одну справку (должна вызвать ошибку)
            student1.requestAbsenceCertificate();

            // Отчисляем студента
            student1.expel();

            // Попытка добавить неправильную оценку (должна вызвать ошибку)
            student1.addGrade("Физика", 150);
        } catch (Exception e) {
            // Логируем ошибку при работе со студентом
            Logger.logError("Ошибка: " + e.getMessage());
        }

        try {
            // Попытка создать студента с неверным форматом телефона (должна вызвать ошибку)
            Student student2 = new Student("Петр Петров", "123456", 2);
        } catch (Exception e) {
            // Логируем ошибку при создании студента
            Logger.logError("Ошибка при создании студента: " + e.getMessage());
        }
    }
}