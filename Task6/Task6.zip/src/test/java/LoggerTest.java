package test.java;
import main.java.Logger;
import org.junit.jupiter.api.Test;

import java.io.BufferedReader;
import java.io.FileReader;
import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;

class LoggerTest {

    @Test
    void testLogAction() throws Exception {
        Path tempFile = Files.createTempFile("actions", ".log");
        Logger.setLogFile(tempFile.toString());
        Logger.logAction("Тестовое действие");
    
        try (BufferedReader reader = new BufferedReader(new FileReader(tempFile.toFile()))) {
            String line = reader.readLine();
            assertNotNull(line);
            assertTrue(line.contains("Тестовое действие"));
        }
        Files.delete(tempFile);
    }

    @Test
    void testLogError() throws Exception {
        Path tempFile = Files.createTempFile("errors", ".log");
        Logger.setErrorLogFile(tempFile.toString());
        Logger.logError("Тестовая ошибка");

        try (BufferedReader reader = new BufferedReader(new FileReader(tempFile.toFile()))) {
            String line = reader.readLine();
            assertNotNull(line);
            assertTrue(line.contains("Тестовая ошибка"));
        }
        Files.delete(tempFile);
    }
}