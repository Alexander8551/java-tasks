import warriors.Warior;
import factories.WariorFactory;
import factories.MageFactory;
import factories.ArcherFactory;

public class Main {
    public static void main(String[] args) {
        // Фабрика, создающая магов
        WariorFactory mageFactory = new MageFactory(10, 5, 50, 1, "Огненная магия");
        // Фабрика, создающая лучников
        WariorFactory archerFactory = new ArcherFactory(7, 3, 40, 1, 15);

        // Создаём мага через фабрику
        Warior mage = mageFactory.createWarior();
        // Вывод информации о маге
        mage.showInfo();
        mage.useUniqueAbility();

        // Создаём лучника через фабрику
        Warior archer = archerFactory.createWarior();
        // Вывод информации о лучнике
        archer.showInfo();
        archer.useUniqueAbility();
    }
}