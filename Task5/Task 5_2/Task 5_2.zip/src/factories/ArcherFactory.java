package factories;

import warriors.Warior;
import warriors.Archer;

public class ArcherFactory implements WariorFactory {
    private int attack;
    private int defense;
    private int health;
    private int level;
    private int range;

    public ArcherFactory(int attack, int defense, int health, int level, int range) {
        this.attack = attack;
        this.defense = defense;
        this.health = health;
        this.level = level;
        this.range = range;
    }

    @Override
    public Warior createWarior() {
        System.out.println("Создаем Archer...");
        return new Archer(attack, defense, health, level, range);
    }
}