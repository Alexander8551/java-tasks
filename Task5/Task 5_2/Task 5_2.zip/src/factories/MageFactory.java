package factories;

import warriors.Warior;
import warriors.Mage;

public class MageFactory implements WariorFactory {
    private int attack;
    private int defense;
    private int health;
    private int level;
    private String magicType;

    public MageFactory(int attack, int defense, int health, int level, String magicType) {
        this.attack = attack;
        this.defense = defense;
        this.health = health;
        this.level = level;
        this.magicType = magicType;
    }

    @Override
    public Warior createWarior() {
        System.out.println("Создаем Mage...");
        return new Mage(attack, defense, health, level, magicType);
    }
}