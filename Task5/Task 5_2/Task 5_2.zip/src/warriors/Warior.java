package warriors;

public abstract class Warior {
    protected int attack;
    protected int defense;
    protected int health;
    protected int level;

    public Warior(int attack, int defense, int health, int level) {
        this.attack = attack;
        this.defense = defense;
        this.health = health;
        this.level = level;
    }

    public abstract void useUniqueAbility();

    public void showInfo() {
        System.out.println(
            "Атака: " + attack +
            ", Защита: " + defense +
            ", Здоровье: " + health +
            ", Уровень: " + level
        );
    }
}