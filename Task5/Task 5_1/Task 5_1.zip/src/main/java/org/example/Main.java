package org.example;

import org.example.AniPatterns.MagicNumbers;

public class Main {
    public static void main(String[] args) {
        MagicNumbers magicNumbers = new MagicNumbers();

        // Проверяем вывод для метода calculate
        System.out.println("Calculation for 400 days: " + magicNumbers.calculate(400));
        System.out.println("Calculation for 50 days: " + magicNumbers.calculate(50));
        System.out.println("Calculation for 10 days: " + magicNumbers.calculate(10));

        // Проверяем вывод для метода getStatus
        System.out.println("Status for code 1: " + magicNumbers.getStatus(1));
        System.out.println("Status for code 2: " + magicNumbers.getStatus(2));
        System.out.println("Status for code 3: " + magicNumbers.getStatus(3));
        System.out.println("Status for code 99: " + magicNumbers.getStatus(99));
        System.out.println("Status for code 0: " + magicNumbers.getStatus(0));

        // Проверка метода process
        System.out.println("Starting process...");
        magicNumbers.process();
        System.out.println("Process completed.");
    }
}
