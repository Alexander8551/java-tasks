package org.example.AniPatterns;

/**
 * Исправление антипаттерна "Магические числа" (Magic Numbers).
 * Для упрощения восприятия кода, объяснения смысла чисел и значений используем константы.
 */

public class MagicNumbers {
    // Константы для расчётов
    private static final int DAYS_IN_YEAR = 365;
    private static final int DAYS_IN_MONTH = 30;
    private static final double YEARLY_DISCOUNT = 0.15;
    private static final double YEARLY_BONUS = 1.1;
    private static final double MONTHLY_DISCOUNT = 0.2;
    private static final double MONTHLY_BONUS = 0.9;
    private static final double DEFAULT_RATE = 0.25;

    // Константы для статусов
    private static final int STATUS_ACTIVE = 1;
    private static final int STATUS_INACTIVE = 2;
    private static final int STATUS_PENDING = 3;
    private static final int STATUS_ERROR = 99;

    // Константа для времени задержки
    private static final int PROCESS_DELAY_MS = 3000;

    public double calculate(int days) {
        if (days > DAYS_IN_YEAR) {
            return days * YEARLY_DISCOUNT * YEARLY_BONUS;
        } else if (days > DAYS_IN_MONTH) {
            return days * MONTHLY_DISCOUNT * MONTHLY_BONUS;
        } else {
            return days * DEFAULT_RATE;
        }
    }

    public String getStatus(int code) {
        switch (code) {
            case STATUS_ACTIVE:
                return "Active";
            case STATUS_INACTIVE:
                return "Inactive";
            case STATUS_PENDING:
                return "Pending";
            case STATUS_ERROR:
                return "Error";
            default:
                return "Unknown";
        }
    }

    public void process() {
        try {
            Thread.sleep(PROCESS_DELAY_MS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}